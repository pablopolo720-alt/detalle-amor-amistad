DETALLE AMOR Y AMISTAD 💛

Archivos:
- index.html
- ramo-amarillo.png

La página funciona con HTML + CSS + JavaScript.
1. Abre index.html.
2. Toca el ramo.
3. Aparecen flores y mariposas amarillas.
4. Aparece el mensaje.
5. Una mariposa vuela y se posa sobre el mensaje.

Para compartirla por un enlace público, sube index.html y ramo-amarillo.png a GitHub Pages, Netlify o similar.
